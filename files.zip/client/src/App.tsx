import React, { useEffect, useRef, useState } from "react";
import mapboxgl from "mapbox-gl";
import io from "socket.io-client";

// Replace with your Mapbox token or use MapLibre + self-hosted tiles
mapboxgl.accessToken = process.env.REACT_APP_MAPBOX_TOKEN || "YOUR_MAPBOX_TOKEN";

type Van = {
  vanId: string;
  lat: number;
  lng: number;
  speed?: number;
  heading?: number;
  recordedAt?: string;
};

export default function App() {
  const mapContainer = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<mapboxgl.Map | null>(null);
  const [vans, setVans] = useState<Record<string, Van>>({});

  useEffect(() => {
    if (!mapContainer.current) return;
    mapRef.current = new mapboxgl.Map({
      container: mapContainer.current,
      style: "mapbox://styles/mapbox/streets-v12",
      center: [-0.1278, 51.5074],
      zoom: 10
    });
    return () => mapRef.current?.remove();
  }, []);

  useEffect(() => {
    const socket = io(process.env.REACT_APP_WS_URL || "http://localhost:4000");
    socket.on("connect", () => console.log("ws connected"));
    socket.on("van-location", (p: any) => {
      const newVans = { ...vans, [p.vanId]: { vanId: p.vanId, lat: p.lat, lng: p.lng, speed: p.speed, heading: p.heading, recordedAt: p.recordedAt } };
      setVans(newVans);
    });
    // Get initial state
    fetch((process.env.REACT_APP_API_URL || "http://localhost:4000") + "/vans/last")
      .then((r) => r.json())
      .then((list) => {
        const map: Record<string, Van> = {};
        list.forEach((row: any) => { map[row.van_id] = { vanId: row.van_id, lat: row.latitude, lng: row.longitude, recordedAt: row.recorded_at }; });
        setVans(map);
      });
    return () => socket.disconnect();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Render markers on map when vans update
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    // Remove existing markers
    // For demo simplicity, create DOM markers and store on map as properties
    // Clear previous markers:
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    if (map._markers) { // poor-man's ephemeral storage
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      map._markers.forEach((m: any) => m.remove());
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    map._markers = [];

    Object.values(vans).forEach((v) => {
      const el = document.createElement("div");
      el.className = "van-marker";
      el.style.width = "18px";
      el.style.height = "18px";
      el.style.background = "orange";
      el.style.borderRadius = "50%";
      el.style.border = "2px white solid";
      const marker = new mapboxgl.Marker(el).setLngLat([v.lng, v.lat]).addTo(map);
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      map._markers.push(marker);
    });
  }, [vans]);

  return (
    <div style={{ height: "100vh", width: "100%" }}>
      <div ref={mapContainer} style={{ height: "100%" }} />
      <style>{`.van-marker{box-shadow:0 0 6px rgba(0,0,0,0.3)}`}</style>
    </div>
  );
}