-- PostGIS schema for vans and location history
CREATE EXTENSION IF NOT EXISTS postgis;

CREATE TABLE IF NOT EXISTS vans (
  id TEXT PRIMARY KEY,
  name TEXT,
  plate TEXT,
  profile JSONB, -- e.g. {"height_m":2.8, "length_m":6.5, "weight_kg":3500, "hazmat":false}
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

CREATE TABLE IF NOT EXISTS van_locations (
  id BIGSERIAL PRIMARY KEY,
  van_id TEXT REFERENCES vans(id) ON DELETE CASCADE,
  recorded_at TIMESTAMP WITH TIME ZONE NOT NULL,
  latitude DOUBLE PRECISION NOT NULL,
  longitude DOUBLE PRECISION NOT NULL,
  geom geometry(Point, 4326) GENERATED ALWAYS AS (ST_SetSRID(ST_MakePoint(longitude, latitude), 4326)) STORED,
  speed_kph DOUBLE PRECISION,
  heading_deg DOUBLE PRECISION,
  meta JSONB
);

CREATE INDEX IF NOT EXISTS idx_van_locations_geom ON van_locations USING GIST (geom);
CREATE INDEX IF NOT EXISTS idx_van_locations_vanid_time ON van_locations (van_id, recorded_at DESC);