/**
 * Geocode marker names using Nominatim (OpenStreetMap).
 * Usage:
 *   npm install node-fetch@2
 *   node scripts/geocode-nominatim.js markers_input.json markers_enriched.json
 *
 * Notes:
 * - Nominatim policy: https://operations.osmfoundation.org/policies/nominatim/
 * - Use a valid User-Agent / email in the script. Keep rate = 1 request/sec for bulk.
 */

const fs = require('fs');
const fetch = require('node-fetch');

const [,, inputFile, outFile] = process.argv;
if (!inputFile || !outFile) {
  console.error('Usage: node scripts/geocode-nominatim.js markers_input.json markers_enriched.json');
  process.exit(1);
}

const USER_AGENT = 'van-aware-map/1.0 (+your-email@example.com)'; // replace your contact

function delay(ms){ return new Promise(r=>setTimeout(r,ms)); }
function queryForMarker(m){
  // Prefer an explicit address if present; else use name + location
  if (m.address) return encodeURIComponent(`${m.name} ${m.address} UK`);
  if (m.location) return encodeURIComponent(`${m.name} ${m.location} UK`);
  return encodeURIComponent(`${m.name} UK`);
}

async function geocodeMarker(m){
  const q = queryForMarker(m);
  const url = `https://nominatim.openstreetmap.org/search?q=${q}&format=json&limit=1&countrycodes=gb`;
  const res = await fetch(url, { headers: { 'User-Agent': USER_AGENT } });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const body = await res.json();
  if (body && body.length) {
    return { latitude: parseFloat(body[0].lat), longitude: parseFloat(body[0].lon), display_name: body[0].display_name };
  }
  return null;
}

(async ()=>{
  const input = JSON.parse(fs.readFileSync(inputFile,'utf8'));
  const out = [];
  for (let i=0;i<input.length;i++){
    const m = input[i];
    try {
      console.log(`[${i+1}/${input.length}] Geocoding: ${m.name}`);
      const res = await geocodeMarker(m);
      if (res) { m.latitude = res.latitude; m.longitude = res.longitude; m._geocode_display = res.display_name; }
      else m._geocode_error = 'no-result';
    } catch (err) {
      console.error('Error geocoding', m.name, err.message);
      m._geocode_error = err.message;
    }
    out.push(m);
    // polite rate limit
    await delay(1100);
    if ((i+1) % 25 === 0) {
      fs.writeFileSync(outFile, JSON.stringify(out, null, 2));
      console.log('Saved progress to', outFile);
    }
  }
  fs.writeFileSync(outFile, JSON.stringify(out, null, 2));
  console.log('Done — output:', outFile);
})();