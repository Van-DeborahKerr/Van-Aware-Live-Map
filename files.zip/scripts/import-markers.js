/**
 * Import enriched markers JSON into Postgres (markers table).
 * Usage:
 *   DATABASE_URL=postgresql://user:pass@host:5432/db node scripts/import-markers.js markers_enriched.json
 *
 * Expects objects with: id, name, location, region, latitude, longitude, image_url, marker_link
 */

const fs = require('fs');
const { Pool } = require('pg');

const [,, inputFile] = process.argv;
if (!inputFile) { console.error('Usage: node scripts/import-markers.js markers_enriched.json'); process.exit(1); }

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function ensureTable(){
  await pool.query(`
    CREATE EXTENSION IF NOT EXISTS postgis;
    CREATE TABLE IF NOT EXISTS markers (
      id TEXT PRIMARY KEY,
      name TEXT,
      location TEXT,
      region TEXT,
      marker_link TEXT,
      image_url TEXT,
      latitude DOUBLE PRECISION,
      longitude DOUBLE PRECISION,
      geom geometry(Point,4326)
    );
  `);
}

(async ()=>{
  const data = JSON.parse(fs.readFileSync(inputFile,'utf8'));
  await ensureTable();
  for (const m of data){
    if (!m.latitude || !m.longitude) { console.log('Skipping (no coords):', m.id || m.name); continue; }
    await pool.query(`
      INSERT INTO markers (id,name,location,region,marker_link,image_url,latitude,longitude,geom)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8, ST_SetSRID(ST_MakePoint($8,$7),4326))
      ON CONFLICT (id) DO UPDATE SET
        name=EXCLUDED.name, location=EXCLUDED.location, region=EXCLUDED.region,
        marker_link=EXCLUDED.marker_link, image_url=EXCLUDED.image_url,
        latitude=EXCLUDED.latitude, longitude=EXCLUDED.longitude, geom=EXCLUDED.geom;
    `, [m.id||null,m.name||null,m.location||null,m.region||null,m.marker_link||null,m.image_url||null,m.latitude,m.longitude]);
    console.log('Upserted:', m.id || m.name);
  }
  await pool.end();
  console.log('Import finished.');
})();