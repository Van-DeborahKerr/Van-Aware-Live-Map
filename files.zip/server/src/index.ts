import express from "express";
import http from "http";
import { Server as IOServer } from "socket.io";
import cors from "cors";
import { Pool } from "pg";
import dotenv from "dotenv";

dotenv.config();

const PORT = process.env.PORT || 4000;
const DATABASE_URL = process.env.DATABASE_URL || "postgresql://demo:demo@localhost:5432/vanmap";

const pool = new Pool({ connectionString: DATABASE_URL });

const app = express();
app.use(cors());
app.use(express.json());

const server = http.createServer(app);
const io = new IOServer(server, {
  cors: { origin: "*" }
});

// WebSocket: clients subscribe to 'van-updates'
io.on("connection", (socket) => {
  console.log("Client connected:", socket.id);
  socket.on("subscribe", (room: string) => {
    socket.join(room);
  });
  socket.on("disconnect", () => {
    // handle disconnect
  });
});

// Simple health check
app.get("/health", (_, res) => res.json({ ok: true }));

// Ingest location update for a van
app.post("/vans/:id/location", async (req, res) => {
  const vanId = req.params.id;
  const { lat, lng, speed, heading, timestamp, meta } = req.body;
  const recordedAt = timestamp ? new Date(timestamp) : new Date();

  if (!lat || !lng) return res.status(400).json({ error: "lat & lng required" });

  try {
    const insertQuery = `
      INSERT INTO van_locations (van_id, recorded_at, latitude, longitude, speed_kph, heading_deg, meta)
      VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING id, recorded_at;
    `;
    const values = [vanId, recordedAt.toISOString(), lat, lng, speed ?? null, heading ?? null, meta ?? {}];
    await pool.query(insertQuery, values);

    // Broadcast via WebSocket
    const payload = { vanId, lat, lng, speed, heading, recordedAt };
    io.emit("van-location", payload); // broadcast to all connected clients (or use rooms)

    res.json({ ok: true });
  } catch (err) {
    console.error("DB/Insert error", err);
    res.status(500).json({ error: "internal" });
  }
});

// Simple endpoint to get last known positions for all vans
app.get("/vans/last", async (_, res) => {
  try {
    const rows = await pool.query(`
      SELECT DISTINCT ON (van_id) van_id, latitude, longitude, recorded_at
      FROM van_locations
      ORDER BY van_id, recorded_at DESC;
    `);
    res.json(rows.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "internal" });
  }
});

server.listen(PORT, () => {
  console.log(`Server listening on ${PORT}`);
});